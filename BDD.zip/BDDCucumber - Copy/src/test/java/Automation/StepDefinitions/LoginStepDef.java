package Automation.StepDefinitions;

import Automation.PageObjects.LoginPage;
import io.cucumber.java.en.*;

public class LoginStepDef extends LoginPage {

    @Given("enter username")
    public void enter_username() throws InterruptedException {
        enter_app_username();
    }

    @Given("enter wrong username")
    public void enter_wrong_username() throws InterruptedException {
        enter_app_wrong_username();
    }


    @When("enter password")
    public void enter_password() throws InterruptedException {
        enter_app_password();
    }

    @Then("click login")
    public void click_login() {
        click_login_button();
    }


}

