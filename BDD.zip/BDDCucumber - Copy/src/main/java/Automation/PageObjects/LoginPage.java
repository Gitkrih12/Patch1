package Automation.PageObjects;

import Automation.Utilities.SeleniumUtils;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class LoginPage extends SeleniumUtils {

    By usernameTxt = By.name("userName");
    By passwordTxt = By.name("password");
    By loginBtn = By.name("submit");

    public void enter_app_username() throws InterruptedException {
        WebElement username1 = explicitElementClickableWait(usernameTxt, 10);
        username1.sendKeys("admin");
    }

    public void enter_app_wrong_username() throws InterruptedException {
        WebElement username1 = explicitElementClickableWait(passwordTxt, 10);
        username1.sendKeys("admin 123456789999");
    }

    public void enter_app_password() throws InterruptedException {
        WebElement password1 = explicitElementClickableWait(passwordTxt, 10);
        password1.sendKeys("admin");
    }

    public void click_login_button() {
        explicitElementClickableWait(loginBtn, 10).click();
        boolean status = driver.getPageSource().contains("Login Successfully");
        Assert.assertTrue("Login was not successful", status);
    }
}
